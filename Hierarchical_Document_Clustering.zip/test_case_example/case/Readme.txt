hca_output.txt:
	This is the output for task1 with command
		python hca.py ./docword.enron_s.txt 5
	In this task, remember not to write the output to any files. Use standard output to print them instead.

kmeans_output.txt:
	This is the output file for task2 with command
		bin\spark-submit .\kmeans.py .\docword.enron_s.txt 10 0.00001 kmeans_output.txt
